<?php
global $WCFM, $WCFMem;
?>
<img style="width: 100%;" src="<?php echo $WCFMem->plugin_url . 'assets/images/store-preview-9000002.png' ?>" alt="">
<?php exit;
