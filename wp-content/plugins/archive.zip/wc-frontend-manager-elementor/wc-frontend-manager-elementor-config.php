<?php

define( 'WCFMem_TOKEN', 'wcfmem');

define( 'WCFM_ELEMENTOR_GROUP', 'wcfm' );

define( 'WCFMem_TEXT_DOMAIN', 'wc-frontend-manager-elementor');

define( 'WCFMem_VERSION', '3.0.3');

define( 'WCFMem_SERVER_URL', 'https://wclovers.com');

define( 'WCFMem_MINIMUM_ELEMENTOR_VERSION', '3.5.6');


?>